<?php $__env->startSection('title', 'Training | Isra e-Logbook'); ?>
<?php $__env->startSection('group_training', 'is-active is-open'); ?>
<?php $__env->startSection('nav_training_list', 'is-active'); ?>
<?php $__env->startSection('main_class', 'elog-main--fluid'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.program-badge', ['program' => request('program', $program ?? '')], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="elog-page-head">
    <h1 class="elog-page-title">Training</h1>
    <a class="btn btn--add" href="<?php echo e(route('training.create', ['program' => request('program')])); ?>">Add New</a>
</div>

<section class="elog-panel">
    <div class="elog-panel__head">
        <span class="elog-panel__head-icon" aria-hidden="true"><i class="fa-solid fa-list"></i></span>
        <span class="elog-panel__head-title">Training</span>
    </div>
    <div class="elog-panel__body">
        <form class="training-filters" method="get" action="<?php echo e(route('training.index')); ?>">
            <?php if(request('program')): ?>
                <input type="hidden" name="program" value="<?php echo e(request('program')); ?>">
            <?php endif; ?>

            <div class="training-filters__grid">
                <div class="field">
                    <label class="field__label" for="f_status">Entry Status</label>
                    <select class="field__control" name="f_status" id="f_status">
                        <?php $__currentLoopData = [''=>'All Entry Status','Draft'=>'Draft','Approved'=>'Approved','Awaiting Approval'=>'Awaiting Approval','Discuss and Resubmit'=>'Discuss and Resubmit']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($val); ?>" <?php echo e(($filters['status'] ?? '') === (string)$val ? 'selected' : ''); ?>><?php echo e($lab); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="field">
                    <label class="field__label" for="f_level">Level</label>
                    <select class="field__control" name="f_level" id="f_level">
                        <option value="">Level</option>
                        <?php $__currentLoopData = ['1'=>'Observer Status','2'=>'Assistant Status','3'=>'Performed under direct Supervision','4'=>'Performed under indirect supervision','5'=>'Performed independently','5555'=>'Other']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($val); ?>" <?php echo e(($filters['level'] ?? '') === (string)$val ? 'selected' : ''); ?>><?php echo e($lab); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="field">
                    <label class="field__label" for="f_post_from">Post Date From</label>
                    <input class="field__control dateBritish" type="text" name="f_post_from" id="f_post_from" placeholder="dd-mm-yyyy" value="<?php echo e($filters['post_from'] ?? ''); ?>">
                </div>
                <div class="field">
                    <label class="field__label" for="f_post_to">Post Date To</label>
                    <input class="field__control dateBritish" type="text" name="f_post_to" id="f_post_to" placeholder="dd-mm-yyyy" value="<?php echo e($filters['post_to'] ?? ''); ?>">
                </div>
                <div class="field">
                    <label class="field__label" for="f_adm_from">Admission Date From</label>
                    <input class="field__control dateBritish" type="text" name="f_adm_from" id="f_adm_from" placeholder="dd-mm-yyyy" value="<?php echo e($filters['adm_from'] ?? ''); ?>">
                </div>
                <div class="field">
                    <label class="field__label" for="f_adm_to">Admission Date To</label>
                    <input class="field__control dateBritish" type="text" name="f_adm_to" id="f_adm_to" placeholder="dd-mm-yyyy" value="<?php echo e($filters['adm_to'] ?? ''); ?>">
                </div>
                <div class="field">
                    <label class="field__label" for="f_reg">Hospt Reg No</label>
                    <input class="field__control" type="text" name="f_reg" id="f_reg" placeholder="Hospt Reg No" value="<?php echo e($filters['reg'] ?? ''); ?>">
                </div>
            </div>

            <?php if($lastEntryLabel): ?>
            <div class="training-filters__actions">
                <span class="training-filters__notice">Last entry added on: <strong><?php echo e($lastEntryLabel); ?></strong></span>
            </div>
            <?php endif; ?>
        </form>

        <div class="elog-table-wrap">
            <table class="elog-table">
                <thead>
                    <tr>
                        <th style="width: 52px;">#</th>
                        <th>Admit Date / Hpt. Reg No</th>
                        <th>Diagnosis</th>
                        <th>Brief Description</th>
                        <th>Competency Group/Details</th>
                        <th>Level</th>
                        <th>Entry Status</th>
                        <th style="width: 100px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td>
                            <div class="cell-admit"><?php echo e($row->date_of_admission ? $row->date_of_admission->format('d-m-Y') : '—'); ?></div>
                            <div class="cell-reg"><?php echo e($row->hospt_reg_no); ?></div>
                        </td>
                        <td><?php echo e($row->pt_diagnosis); ?></td>
                        <td><div class="cell-brief"><?php echo e(Str::limit(strip_tags($row->brief_desc), 100)); ?></div></td>
                        <td class="cell-comp"><?php echo app(\App\Services\CompetencyService::class)->formatCell($row->com_ids, $row->com_detail_ids, $compMap); ?></td>
                        <td><?php echo e(['1'=>'Observer','2'=>'Assistant','3'=>'Direct','4'=>'Indirect','5'=>'Independent','5555'=>'Other'][$row->level_id] ?? $row->level_id); ?></td>
                        <td>
                            <div class="cell-status">
                                <div>Add: <?php echo e($row->created_at?->format('d-m-Y')); ?></div>
                                <?php
                                    $sBadge = match($row->entry_status) {
                                        'Approved' => 'ok',
                                        'Awaiting Approval' => 'warn',
                                        'Discuss and Resubmit' => 'info',
                                        'Disapproved' => 'danger',
                                        default => 'muted',
                                    };
                                ?>
                                <span class="badge badge--<?php echo e($sBadge); ?>"><?php echo e($row->entry_status ?: 'Draft'); ?></span>
                                <?php if($row->approved_at): ?>
                                    <div>Appr: <?php echo e($row->approved_at->format('d-m-Y')); ?></div>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <a class="btn btn--view" href="<?php echo e(route('training.show', $row->id)); ?>" title="View"><i class="fa-solid fa-eye"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="elog-table__empty">No entries found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\logbook\ISRA-E-Logbook\cpsp-multitenant\resources\views/training/index.blade.php ENDPATH**/ ?>