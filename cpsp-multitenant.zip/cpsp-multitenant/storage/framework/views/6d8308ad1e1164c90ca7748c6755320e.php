<?php $__env->startSection('title', 'Suggestions | Isra e-Logbook'); ?>
<?php $__env->startSection('group_suggestions', 'is-active is-open'); ?>
<?php $__env->startSection('nav_suggestions_list', 'is-active'); ?>
<?php $__env->startSection('main_class', 'elog-main--fluid'); ?>

<?php $__env->startSection('content'); ?>
<div class="elog-page-head">
    <h1 class="elog-page-title">Suggestions</h1>
</div>

<section class="elog-panel">
    <div class="elog-panel__head">
        <span class="elog-panel__head-icon" aria-hidden="true"><i class="fa-solid fa-lightbulb"></i></span>
        <span class="elog-panel__head-title">Submit a Suggestion</span>
    </div>
    <div class="elog-panel__body">
        <form class="form-horizontal elog-form" action="<?php echo e(route('suggestions.store')); ?>" method="post" id="suggestionsForm" novalidate>
            <?php echo csrf_field(); ?>
            <?php if(request('program')): ?>
                <input type="hidden" name="program" value="<?php echo e(request('program')); ?>">
            <?php endif; ?>

            <div class="row elog-form__row elog-form__row--1">
                <div class="col-md-12">
                    <label class="control-label" for="suggestion_text">Your Suggestion / Feedback <span class="vd_red">*</span></label>
                    <div class="controls">
                        <textarea id="suggestion_text" name="suggestion_text" class="field__control" rows="6" placeholder="Type your feedback here..." required></textarea>
                    </div>
                </div>
            </div>

            <div class="form-actions-condensed row elog-form__row elog-form__row--1 mgbt-xs-0">
                <div class="col-sm-12">
                    <button class="btn btn--submit" type="submit" id="suggestions_submit">Submit Suggestion</button>
                </div>
            </div>
        </form>
    </div>
</section>

<section class="elog-panel" style="margin-top: 1.5rem;">
    <div class="elog-panel__head">
        <span class="elog-panel__head-icon" aria-hidden="true"><i class="fa-solid fa-list"></i></span>
        <span class="elog-panel__head-title">Previous Suggestions</span>
    </div>
    <div class="elog-panel__body">
        <div class="elog-table-wrap">
            <table class="elog-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">#</th>
                        <th>Suggestion / Feedback</th>
                        <th style="width: 140px;">Submitted On</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $suggestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($i + 1); ?></td>
                        <td><?php echo nl2br(e($s->suggestion_text)); ?></td>
                        <td><?php echo e($s->created_at?->format('d-m-Y')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3" class="elog-table__empty">No suggestions submitted yet.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\logbook\ISRA-E-Logbook\cpsp-multitenant\resources\views/suggestions/index.blade.php ENDPATH**/ ?>