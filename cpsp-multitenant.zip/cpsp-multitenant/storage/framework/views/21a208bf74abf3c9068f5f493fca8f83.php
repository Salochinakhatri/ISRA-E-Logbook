<?php $__env->startSection('title', 'Journal Club | Isra e-Logbook'); ?>
<?php $__env->startSection('group_journal', 'is-active is-open'); ?>
<?php $__env->startSection('nav_journal_list', 'is-active'); ?>
<?php $__env->startSection('main_class', 'elog-main--fluid'); ?>

<?php $__env->startSection('content'); ?>
<div class="elog-page-head">
    <h1 class="elog-page-title">Journal Club</h1>
    <a class="btn btn--add" href="<?php echo e(route('journal.create', ['program' => request('program')])); ?>">Add New</a>
</div>

<section class="elog-panel">
    <div class="elog-panel__head">
        <span class="elog-panel__head-icon" aria-hidden="true"><i class="fa-solid fa-list"></i></span>
        <span class="elog-panel__head-title">Journal Club</span>
    </div>
    <div class="elog-panel__body">
        <div class="elog-table-wrap">
            <table class="elog-table">
                <thead>
                    <tr>
                        <th style="width: 48px;">#</th>
                        <th style="width: 140px;">Date of Discussion</th>
                        <th style="width: 160px;">Facilitated By</th>
                        <th>Reference Of The Article Discussed</th>
                        <th style="width: 130px;">Entry Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($i + 1); ?></td>
                        <td><?php echo e($row->date_of_diss ? $row->date_of_diss->format('d-m-Y') : '—'); ?></td>
                        <td><?php echo e($row->fac_by); ?></td>
                        <td><?php echo e(Str::limit($row->ref_of_art_disc ?: ($row->topic . ($row->ref_article ? ' - ' . $row->ref_article : '')), 120)); ?></td>
                        <td>
                            <div class="cell-status">
                                <div>Add: <?php echo e($row->created_at?->format('d-m-Y')); ?></div>
                                <span class="badge badge--<?php echo e($row->entry_status === 'Approved' ? 'ok' : ($row->entry_status === 'Draft' ? 'muted' : 'warn')); ?>">
                                    <?php echo e($row->entry_status ?: 'Draft'); ?>

                                </span>
                                <?php if($row->approved_at): ?>
                                    <div>Approved: <?php echo e($row->approved_at->format('d-m-Y')); ?></div>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="elog-table__empty">No journal club entries found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\logbook\ISRA-E-Logbook\cpsp-multitenant\resources\views/journal/index.blade.php ENDPATH**/ ?>