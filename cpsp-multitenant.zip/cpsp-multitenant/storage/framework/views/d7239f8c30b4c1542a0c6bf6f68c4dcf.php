<?php if(!empty($program)): ?>
    <?php
        $progMeta = \App\Models\Tenant::getProgramMeta($program);
    ?>
    <div class="elog-program-badge">
        <span class="badge <?php echo e($progMeta['badge_class']); ?>"><i class="<?php echo e($progMeta['icon']); ?>"></i> <?php echo $progMeta['label']; ?></span>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\logbook\ISRA-E-Logbook\cpsp-multitenant\resources\views/partials/program-badge.blade.php ENDPATH**/ ?>