<?php $__env->startSection('title', ($tenant->name ?? 'e-Logbook') . ' - Supervisor Dashboard'); ?>
<?php $__env->startSection('nav_home', 'is-active'); ?>

<?php $__env->startSection('content'); ?>
<div class="supervisor-dash">
    
    <nav class="supervisor-dash__breadcrumb" aria-label="breadcrumb">
        <ol class="breadcrumb-list">
            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
            <li class="breadcrumb-item separator">/</li>
            <li class="breadcrumb-item active" aria-current="page">e-Logbook Dashboard</li>
        </ol>
    </nav>

    
    <div class="supervisor-dash__header">
        <h1 class="supervisor-dash__title"><?php echo e($tenant->name ?? 'CPSP e-Logbook'); ?></h1>
        <span class="visually-hidden">CPSP e-Logbook</span>
        <?php if($stats['total_pending'] > 0): ?>
            <div class="supervisor-dash__alert-badge">
                <i class="fa-solid fa-bell"></i>
                <span><strong><?php echo e($stats['total_pending']); ?></strong> <?php echo e(Str::plural('entry', $stats['total_pending'])); ?> awaiting your approval</span>
                <a href="<?php echo e(route('supervisor.entries')); ?>" class="btn-review-now">Review All</a>
            </div>
        <?php endif; ?>
    </div>

    
    <div class="supervisor-stats-grid">
        
        <div class="sup-stat-card sup-stat-card--teal">
            <div class="sup-stat-card__body">
                <div class="sup-stat-card__icon">
                    <i class="fa-solid fa-thumbs-up"></i>
                </div>
                <div class="sup-stat-card__number"><?php echo e($stats['feedback_trainee']); ?></div>
            </div>
            <div class="sup-stat-card__footer">
                FEEDBACK ABOUT TRAINEE
            </div>
        </div>

        
        <div class="sup-stat-card sup-stat-card--orange">
            <div class="sup-stat-card__body">
                <div class="sup-stat-card__icon">
                    <i class="fa-solid fa-gauge-high"></i>
                </div>
                <div class="sup-stat-card__number"><?php echo e($stats['cme_credits']); ?></div>
            </div>
            <div class="sup-stat-card__footer">
                CME CREDITS
            </div>
        </div>

        
        <a href="<?php echo e(route('supervisor.entries', ['status' => 'all'])); ?>" class="sup-stat-card sup-stat-card--grey" style="text-decoration: none;">
            <div class="sup-stat-card__body">
                <div class="sup-stat-card__icon">
                    <i class="fa-solid fa-list-ul"></i>
                </div>
                <div class="sup-stat-card__number" style="font-size: 1.5rem; padding-top: 6px;">VIEW</div>
            </div>
            <div class="sup-stat-card__footer">
                REPORTS
            </div>
        </a>

        
        <div class="sup-stat-card sup-stat-card--blue">
            <div class="sup-stat-card__body">
                <div class="sup-stat-card__icon">
                    <i class="fa-solid fa-thumbs-up"></i>
                </div>
                <div class="sup-stat-card__number"><?php echo e($stats['workshop_feedback']); ?></div>
            </div>
            <div class="sup-stat-card__footer">
                WORKSHOP FEEDBACK
            </div>
        </div>
    </div>

    
    <div class="sup-panel" id="panelCurrentTrainees">
        <div class="sup-panel__header">
            <div class="sup-panel__title">
                <i class="fa-regular fa-circle-dot"></i>
                <span>Current Trainees - Awaiting Approval Entries</span>
            </div>
            <button type="button" class="sup-panel__toggle" data-target="#currentTraineesContent" aria-label="Toggle panel">
                <i class="fa-solid fa-minus"></i>
            </button>
        </div>
        <div class="sup-panel__content" id="currentTraineesContent">
            <div class="table-responsive">
                <table class="sup-table">
                    <thead>
                        <tr>
                            <th style="width: 40px;">#</th>
                            <th>Name</th>
                            <th style="text-align: center;">Training</th>
                            <th style="text-align: center;">Rotational Training</th>
                            <th style="text-align: center;">Journal Club</th>
                            <th style="text-align: center;">Paper / Poster</th>
                            <th style="text-align: center;">Paper Published</th>
                            <th style="text-align: center;">Record of Training</th>
                            <th style="text-align: center;">Total</th>
                            <th style="text-align: center;">Workshops / Synopsis / Dissertation</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $currentTrainees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $trainee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td>
                                <div class="sup-trainee-name"><?php echo e($trainee['name']); ?></div>
                                <div class="sup-trainee-sub">ID: <?php echo e($trainee['username']); ?></div>
                            </td>
                            <td style="text-align: center;">
                                <?php if($trainee['training'] > 0): ?>
                                    <a href="<?php echo e(route('supervisor.entries', ['trainee_id' => $trainee['id'], 'type' => 'training', 'status' => 'Awaiting Approval'])); ?>" class="sup-count-badge sup-count-badge--warn" title="Click to review <?php echo e($trainee['training']); ?> training entries">
                                        <?php echo e($trainee['training']); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="sup-count-zero">0</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center;">
                                <?php if($trainee['rotational'] > 0): ?>
                                    <a href="<?php echo e(route('supervisor.entries', ['trainee_id' => $trainee['id'], 'type' => 'rotational', 'status' => 'Awaiting Approval'])); ?>" class="sup-count-badge sup-count-badge--warn" title="Click to review <?php echo e($trainee['rotational']); ?> rotational entries">
                                        <?php echo e($trainee['rotational']); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="sup-count-zero">0</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center;">
                                <?php if($trainee['journal'] > 0): ?>
                                    <a href="<?php echo e(route('supervisor.entries', ['trainee_id' => $trainee['id'], 'type' => 'journal', 'status' => 'Awaiting Approval'])); ?>" class="sup-count-badge sup-count-badge--warn" title="Click to review <?php echo e($trainee['journal']); ?> journal club entries">
                                        <?php echo e($trainee['journal']); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="sup-count-zero">0</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center;">
                                <?php if($trainee['presented'] > 0): ?>
                                    <a href="<?php echo e(route('supervisor.entries', ['trainee_id' => $trainee['id'], 'type' => 'presented', 'status' => 'Awaiting Approval'])); ?>" class="sup-count-badge sup-count-badge--warn" title="Click to review <?php echo e($trainee['presented']); ?> presented paper entries">
                                        <?php echo e($trainee['presented']); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="sup-count-zero">0</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center;">
                                <?php if($trainee['published'] > 0): ?>
                                    <a href="<?php echo e(route('supervisor.entries', ['trainee_id' => $trainee['id'], 'type' => 'published', 'status' => 'Awaiting Approval'])); ?>" class="sup-count-badge sup-count-badge--warn" title="Click to review <?php echo e($trainee['published']); ?> published paper entries">
                                        <?php echo e($trainee['published']); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="sup-count-zero">0</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center;">
                                <span class="sup-count-zero">0</span>
                            </td>
                            <td style="text-align: center;">
                                <?php if($trainee['total'] > 0): ?>
                                    <a href="<?php echo e(route('supervisor.entries', ['trainee_id' => $trainee['id'], 'status' => 'Awaiting Approval'])); ?>" class="sup-count-badge sup-count-badge--total" title="Review all <?php echo e($trainee['total']); ?> awaiting entries">
                                        <?php echo e($trainee['total']); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="sup-count-zero">0</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center;">
                                <div class="btn-group-action">
                                    <a href="<?php echo e(route('supervisor.entries', ['trainee_id' => $trainee['id']])); ?>" class="btn-sup-action" title="View all entries by this trainee">
                                        <i class="fa-solid fa-list-check"></i> Review (<?php echo e($trainee['total']); ?>)
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="10" class="sup-table__empty">No trainees found for this department.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <div class="sup-panel" id="panelRotationalTrainees">
        <div class="sup-panel__header">
            <div class="sup-panel__title">
                <i class="fa-regular fa-circle-dot"></i>
                <span>Rotational Trainees - Awaiting Approval Entries</span>
            </div>
            <button type="button" class="sup-panel__toggle" data-target="#rotationalTraineesContent" aria-label="Toggle panel">
                <i class="fa-solid fa-minus"></i>
            </button>
        </div>
        <div class="sup-panel__content" id="rotationalTraineesContent">
            <div class="table-responsive">
                <table class="sup-table">
                    <thead>
                        <tr>
                            <th style="width: 40px;">#</th>
                            <th>Name</th>
                            <th>ID / Username</th>
                            <th>RTMC No</th>
                            <th>Rotation Speciality</th>
                            <th>Rotation Time Period</th>
                            <th style="text-align: center;">Entries</th>
                            <th style="text-align: center;">Workshops / Synopsis / Dissertation</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $rotationalTrainees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $rt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($idx + 1); ?></td>
                            <td><strong><?php echo e($rt['name']); ?></strong></td>
                            <td><?php echo e($rt['username']); ?></td>
                            <td>RTMC-<?php echo e($rt['id']); ?></td>
                            <td>General Surgery / Medicine</td>
                            <td>Current Rotation</td>
                            <td style="text-align: center;">
                                <a href="<?php echo e(route('supervisor.entries', ['trainee_id' => $rt['id'], 'type' => 'rotational', 'status' => 'Awaiting Approval'])); ?>" class="sup-count-badge sup-count-badge--warn">
                                    <?php echo e($rt['rotational']); ?>

                                </a>
                            </td>
                            <td style="text-align: center;">
                                <a href="<?php echo e(route('supervisor.entries', ['trainee_id' => $rt['id'], 'type' => 'rotational'])); ?>" class="btn-sup-action">
                                    <i class="fa-solid fa-eye"></i> View Entries
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="sup-table__empty">No rotational trainees currently awaiting approval.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
    <div class="sup-panel" id="panelPreviousTrainees">
        <div class="sup-panel__header">
            <div class="sup-panel__title">
                <i class="fa-regular fa-circle-dot"></i>
                <span>Previous Trainees - Awaiting Approval Entries</span>
            </div>
            <button type="button" class="sup-panel__toggle" data-target="#previousTraineesContent" aria-label="Toggle panel">
                <i class="fa-solid fa-minus"></i>
            </button>
        </div>
        <div class="sup-panel__content" id="previousTraineesContent">
            <div class="table-responsive">
                <table class="sup-table">
                    <thead>
                        <tr>
                            <th style="width: 40px;">#</th>
                            <th>Name</th>
                            <th style="text-align: center;">Training</th>
                            <th style="text-align: center;">Rotational Training</th>
                            <th style="text-align: center;">Journal Club</th>
                            <th style="text-align: center;">Paper / Poster</th>
                            <th style="text-align: center;">Paper Published</th>
                            <th style="text-align: center;">Record of Training</th>
                            <th style="text-align: center;">Total</th>
                            <th style="text-align: center;">Workshops / Synopsis / Dissertation</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="10" class="sup-table__empty">No previous trainees awaiting approval entries.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <footer class="sup-footer">
        <p>Copyright &copy; <?php echo e(date('Y')); ?> <?php echo e($tenant->name ?? 'CPSP'); ?>. All Rights Reserved</p>
    </footer>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    // Accordion toggle behavior for minus / plus
    var toggles = document.querySelectorAll('.sup-panel__toggle');
    toggles.forEach(function (btn) {
        btn.addEventListener('click', function () {
            var targetId = this.getAttribute('data-target');
            var target = document.querySelector(targetId);
            var icon = this.querySelector('i');
            if (!target) return;

            if (target.style.display === 'none') {
                target.style.display = 'block';
                if (icon) {
                    icon.classList.remove('fa-plus');
                    icon.classList.add('fa-minus');
                }
            } else {
                target.style.display = 'none';
                if (icon) {
                    icon.classList.remove('fa-minus');
                    icon.classList.add('fa-plus');
                }
            }
        });
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\logbook\ISRA-E-Logbook\cpsp-multitenant\resources\views/dashboard/supervisor.blade.php ENDPATH**/ ?>