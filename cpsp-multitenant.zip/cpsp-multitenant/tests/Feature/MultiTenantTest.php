<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\Tenant;
use App\Models\TrainingEntry;
use App\Models\User;
use App\Models\UserType;
use App\Services\TenantManager;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Tests\TestCase;

class MultiTenantTest extends TestCase
{
    use DatabaseTransactions;
    public function test_unknown_domain_returns_404(): void
    {
        $response = $this->get('http://unknown-domain.test/');
        $response->assertStatus(404);
    }

    public function test_cpsp1_domain_resolves_tenant_and_shows_login(): void
    {
        $response = $this->get('http://cpsp1.test/');
        $response->assertStatus(200);
        $response->assertSee('CPSP ePortal');
        $response->assertSee('LOGIN TO YOUR ACCOUNT');
    }

    public function test_cpsp2_domain_resolves_tenant_and_shows_login(): void
    {
        $response = $this->get('http://cpsp2.test/');
        $response->assertStatus(200);
        $response->assertSee('CPSP ePortal');
        $response->assertSee('LOGIN TO YOUR ACCOUNT');
    }

    public function test_trainee_login_success_and_redirection(): void
    {
        $cpsp1 = Tenant::where('domain', 'cpsp1.test')->firstOrFail();
        $traineeType = UserType::where('tenant_id', $cpsp1->id)->where('name', 'Trainee')->firstOrFail();

        $response = $this->post('http://cpsp1.test/login', [
            'user_type_id' => $traineeType->id,
            'username'     => '2022-23675',
            'password'     => 'password',
        ]);

        $response->assertRedirect('/dashboard');
        $response->assertSessionHas('user_id');
        $response->assertSessionHas('username', '2022-23675');
    }

    public function test_invalid_credentials_fail(): void
    {
        $cpsp1 = Tenant::where('domain', 'cpsp1.test')->firstOrFail();
        $traineeType = UserType::where('tenant_id', $cpsp1->id)->where('name', 'Trainee')->firstOrFail();

        $response = $this->post('http://cpsp1.test/login', [
            'user_type_id' => $traineeType->id,
            'username'     => '2022-23675',
            'password'     => 'wrongpassword',
        ]);

        $response->assertRedirect('http://cpsp1.test');
        $response->assertSessionHas('login_error');
    }

    public function test_unauthenticated_user_redirected_from_dashboard(): void
    {
        $response = $this->get('http://cpsp1.test/dashboard');
        $response->assertRedirect('http://cpsp1.test');
    }

    public function test_authenticated_trainee_accesses_dashboard(): void
    {
        $cpsp1 = Tenant::where('domain', 'cpsp1.test')->firstOrFail();
        $user  = User::withoutGlobalScope('tenant')
            ->where('tenant_id', $cpsp1->id)
            ->where('username', '2022-23675')
            ->firstOrFail();

        $response = $this->withSession([
            'user_id'      => $user->id,
            'user_type_id' => $user->user_type_id,
            'username'     => $user->username,
            'email'        => $user->email,
            'user_type'    => 'Trainee',
        ])->get('http://cpsp1.test/dashboard');

        $response->assertStatus(200);
        $response->assertSee('INTERNAL MEDICINE');
        $response->assertSee('Isra e-Logbook');
        $response->assertSee('Training');
        $response->assertSee('Rotational');
        $response->assertSee('Journal');
    }

    public function test_tenant_scoping_training_entry_isolation(): void
    {
        $tenantManager = app(TenantManager::class);

        $cpsp1 = Tenant::where('domain', 'cpsp1.test')->firstOrFail();
        $cpsp2 = Tenant::where('domain', 'cpsp2.test')->firstOrFail();

        $user1 = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->firstOrFail();
        $user2 = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp2->id)->firstOrFail();

        // Under Tenant 1
        $tenantManager->set($cpsp1);
        $entry1 = TrainingEntry::create([
            'user_id'           => $user1->id,
            'entry_type'        => 'training',
            'form_type'         => '1',
            'hospt_reg_no'      => 'REG-TENANT-1-ISOLATION',
            'pt_diagnosis'      => 'Appendicitis',
            'brief_desc'        => 'Laparoscopic appendectomy performed',
            'level_id'          => '3',
            'outcome_id'        => '8',
            'under_sup_name'    => 'Dr. Supervisor',
            'pt_gender'         => 'Male',
            'pt_age'            => '35',
            'pt_age_type'       => 'Year[s]',
            'std_post'          => 'No',
            'entry_status'      => 'Draft',
        ]);

        $this->assertEquals($cpsp1->id, $entry1->tenant_id);

        // Tenant 1 should see entry1
        $this->assertNotNull(TrainingEntry::where('hospt_reg_no', 'REG-TENANT-1-ISOLATION')->first());

        // Switch to Tenant 2
        $tenantManager->set($cpsp2);
        $this->assertNull(TrainingEntry::where('hospt_reg_no', 'REG-TENANT-1-ISOLATION')->first());

        // Clean up test entry
        $entry1->delete();
    }

    public function test_program_badges_for_gynae_and_obs(): void
    {
        $cpsp2 = Tenant::where('domain', 'cpsp2.test')->firstOrFail();
        $user2  = User::withoutGlobalScope('tenant')
            ->where('tenant_id', $cpsp2->id)
            ->where('username', '2022-23675')
            ->firstOrFail();

        $responseMs = $this->withSession([
            'user_id'      => $user2->id,
            'user_type_id' => $user2->user_type_id,
            'username'     => $user2->username,
            'email'        => $user2->email,
            'user_type'    => 'Trainee',
        ])->get('http://cpsp2.test/training?program=ms');

        $responseMs->assertStatus(200);
        $responseMs->assertSee('MS (GYNAECOLOGY & OBSTETRICS)', false);

        $responseDgo = $this->withSession([
            'user_id'      => $user2->id,
            'user_type_id' => $user2->user_type_id,
            'username'     => $user2->username,
            'email'        => $user2->email,
            'user_type'    => 'Trainee',
        ])->get('http://cpsp2.test/training?program=dgo');

        $responseDgo->assertStatus(200);
        $responseDgo->assertSee('DGO (GYNAECOLOGY & OBSTETRICS)', false);

        $cpsp1 = Tenant::where('domain', 'cpsp1.test')->firstOrFail();
        $user1  = User::withoutGlobalScope('tenant')
            ->where('tenant_id', $cpsp1->id)
            ->where('username', '2022-23675')
            ->firstOrFail();

        $responseMd = $this->withSession([
            'user_id'      => $user1->id,
            'user_type_id' => $user1->user_type_id,
            'username'     => $user1->username,
            'email'        => $user1->email,
            'user_type'    => 'Trainee',
        ])->get('http://cpsp1.test/training?program=md');

        $responseMd->assertStatus(200);
        $responseMd->assertSee('MD (INTERNAL MEDICINE)');
    }

    public function test_trainee_can_create_and_list_training_entry(): void
    {
        $cpsp1 = Tenant::where('domain', 'cpsp1.test')->firstOrFail();
        $user  = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', '2022-23675')->firstOrFail();

        $session = [
            'user_id'      => $user->id,
            'user_type_id' => $user->user_type_id,
            'username'     => $user->username,
            'email'        => $user->email,
            'user_type'    => 'Trainee',
        ];

        // Access create form
        $this->withSession($session)->get('http://cpsp1.test/training/create')->assertStatus(200);

        // Store new entry
        $postResponse = $this->withSession($session)->post('http://cpsp1.test/training', [
            'form_type'         => '1',
            'hospt_reg_no'      => 'REG-AUTO-TEST-001',
            'date_of_admission' => '15-08-2026',
            'pt_gender'         => 'Male',
            'pt_age'            => '28',
            'pt_age_type'       => 'Year[s]',
            'pt_diagnosis'      => 'Acute Appendicitis',
            'under_sup_name'    => 'Dr. Supervisor Demo',
            'level_id'          => '3',
            'outcome_id'        => '8',
            'brief_desc'        => 'Successful procedure with standard protocol.',
            'std_post'          => 'No',
        ]);

        $postResponse->assertRedirect('http://cpsp1.test/training');

        // Check it appears in listing
        $listResponse = $this->withSession($session)->get('http://cpsp1.test/training');
        $listResponse->assertStatus(200);
        $listResponse->assertSee('REG-AUTO-TEST-001');
        $listResponse->assertSee('Acute Appendicitis');
    }

    public function test_journal_entry_creation_and_listing(): void
    {
        $cpsp1 = Tenant::where('domain', 'cpsp1.test')->firstOrFail();
        $user  = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', '2022-23675')->firstOrFail();

        $session = [
            'user_id'      => $user->id,
            'user_type_id' => $user->user_type_id,
            'username'     => $user->username,
            'email'        => $user->email,
            'user_type'    => 'Trainee',
        ];

        $postResponse = $this->withSession($session)->post('http://cpsp1.test/journal', [
            'date_of_diss'    => '20-08-2026',
            'fac_by'          => 'Dr. Facilitator',
            'ref_of_art_disc' => 'NEJM Article On Clinical Trials 2026',
            'std_post'        => 'No',
        ]);

        $postResponse->assertRedirect('http://cpsp1.test/journal');

        $listResponse = $this->withSession($session)->get('http://cpsp1.test/journal');
        $listResponse->assertStatus(200);
        $listResponse->assertSee('Dr. Facilitator');
        $listResponse->assertSee('NEJM Article On Clinical Trials 2026');
    }

    public function test_suggestions_submission_and_listing(): void
    {
        $cpsp2 = Tenant::where('domain', 'cpsp2.test')->firstOrFail();
        $user  = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp2->id)->where('username', '2022-23675')->firstOrFail();

        $session = [
            'user_id'      => $user->id,
            'user_type_id' => $user->user_type_id,
            'username'     => $user->username,
            'email'        => $user->email,
            'user_type'    => 'Trainee',
        ];

        $postResponse = $this->withSession($session)->post('http://cpsp2.test/suggestions', [
            'suggestion_text' => 'Please add an export feature for weekly logs.',
        ]);

        $postResponse->assertRedirect('http://cpsp2.test/suggestions');

        $listResponse = $this->withSession($session)->get('http://cpsp2.test/suggestions');
        $listResponse->assertStatus(200);
        $listResponse->assertSee('Please add an export feature for weekly logs.');
    }

    public function test_supervisor_sees_supervisor_dashboard(): void
    {
        $cpsp1 = Tenant::where('domain', 'cpsp1.test')->firstOrFail();
        $supervisor = User::withoutGlobalScope('tenant')
            ->where('tenant_id', $cpsp1->id)
            ->where('username', 'supervisor01')
            ->firstOrFail();

        $response = $this->withSession([
            'user_id'      => $supervisor->id,
            'user_type_id' => $supervisor->user_type_id,
            'username'     => $supervisor->username,
            'email'        => $supervisor->email,
            'user_type'    => 'Supervisor',
        ])->get('http://cpsp1.test/dashboard');

        $response->assertStatus(200);
        $response->assertSee('CPSP e-Logbook');
        $response->assertSee('Current Trainees - Awaiting Approval Entries');
        $response->assertSee('supervisor01');
    }

    public function test_logout_invalidates_session(): void
    {
        $response = $this->withSession([
            'user_id'   => 1,
            'username'  => '2022-23675',
            'user_type' => 'Trainee',
        ])->post('http://cpsp1.test/logout');

        $response->assertRedirect('http://cpsp1.test');
        $response->assertSessionMissing('user_id');
    }

    public function test_switching_tenant_does_not_404(): void
    {
        $cpsp1 = Tenant::where('domain', 'cpsp1.test')->firstOrFail();
        $user1 = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', '2022-23675')->firstOrFail();

        // User logged into cpsp1 then accesses cpsp2 dashboard
        $response = $this->withSession([
            'user_id'   => $user1->id,
            'tenant_id' => $user1->tenant_id,
            'username'  => $user1->username,
            'user_type' => 'Trainee',
        ])->get('http://cpsp2.test/dashboard');

        // Should gracefully redirect to login for cpsp2, NEVER 404
        $response->assertRedirect('http://cpsp2.test');
    }

    public function test_search_with_empty_filters_completes_successfully(): void
    {
        $cpsp2 = Tenant::where('domain', 'cpsp2.test')->firstOrFail();
        $user2 = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp2->id)->where('username', '2022-23675')->firstOrFail();

        $response = $this->withSession([
            'user_id'   => $user2->id,
            'tenant_id' => $user2->tenant_id,
            'username'  => $user2->username,
            'user_type' => 'Trainee',
        ])->get('http://cpsp2.test/training?program=ms&f_status=&f_level=&f_post_from=&f_post_to=&f_adm_from=&f_adm_to=&f_reg=');

        $response->assertStatus(200);
        $response->assertSee('Training');
    }

    public function test_supervisor_can_view_and_approve_trainee_entries(): void
    {
        $cpsp1 = Tenant::where('domain', 'cpsp1.test')->firstOrFail();
        $trainee = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', '2022-23675')->firstOrFail();
        $supervisor = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'supervisor01')->firstOrFail();

        // Create an entry awaiting approval
        $entry = TrainingEntry::withoutGlobalScope('tenant')->create([
            'tenant_id'         => $cpsp1->id,
            'user_id'           => $trainee->id,
            'entry_type'        => 'training',
            'form_type'         => '1',
            'hospt_reg_no'      => 'REG-APPR-TEST-001',
            'pt_diagnosis'      => 'Acute Cholecystitis',
            'brief_desc'        => 'Laparoscopic cholecystectomy performed uneventfully',
            'level_id'          => '3',
            'outcome_id'        => '8',
            'under_sup_name'    => 'Dr. Supervisor Demo',
            'pt_gender'         => 'Female',
            'pt_age'            => '42',
            'pt_age_type'       => 'Year[s]',
            'std_post'          => 'Yes',
            'entry_status'      => 'Awaiting Approval',
        ]);

        // Supervisor visits /supervisor/entries
        $response = $this->withSession([
            'user_id'      => $supervisor->id,
            'tenant_id'    => $supervisor->tenant_id,
            'user_type_id' => $supervisor->user_type_id,
            'username'     => $supervisor->username,
            'user_type'    => 'Supervisor',
        ])->get('http://cpsp1.test/supervisor/entries');

        $response->assertStatus(200);
        $response->assertSee('Acute Cholecystitis');
        $response->assertSee('Awaiting Approval');

        // Supervisor approves the entry
        $approveResponse = $this->withSession([
            'user_id'      => $supervisor->id,
            'tenant_id'    => $supervisor->tenant_id,
            'user_type_id' => $supervisor->user_type_id,
            'username'     => $supervisor->username,
            'user_type'    => 'Supervisor',
        ])->post("http://cpsp1.test/supervisor/entries/training/{$entry->id}/status", [
            'status'             => 'Approved',
            'supervisor_remarks' => 'Well documented procedure and good technique.',
        ]);

        $approveResponse->assertRedirect();
        $entry->refresh();
        $this->assertEquals('Approved', $entry->entry_status);
        $this->assertNotNull($entry->approved_at);
        $this->assertEquals($supervisor->id, $entry->approved_by);
        $this->assertEquals('Well documented procedure and good technique.', $entry->supervisor_remarks);

        // Clean up
        $entry->delete();
    }

    public function test_roles_table_and_user_roles_associations(): void
    {
        $cpsp1 = Tenant::where('domain', 'cpsp1.test')->firstOrFail();

        // Roles exist
        $traineeRole = \App\Models\Role::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('slug', 'trainee')->first();
        $supervisorRole = \App\Models\Role::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('slug', 'supervisor')->first();

        $this->assertNotNull($traineeRole);
        $this->assertNotNull($supervisorRole);
        $this->assertEquals('Trainee', $traineeRole->name);
        $this->assertEquals('Supervisor', $supervisorRole->name);

        // Users are linked to their roles
        $trainee = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', '2022-23675')->firstOrFail();
        $supervisor = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'supervisor01')->firstOrFail();

        $this->assertTrue($trainee->hasRole('trainee'));
        $this->assertTrue($trainee->isTrainee());
        $this->assertFalse($trainee->isSupervisor());

        $this->assertTrue($supervisor->hasRole('supervisor'));
        $this->assertTrue($supervisor->isSupervisor());
        $this->assertFalse($supervisor->isTrainee());

        $this->assertEquals($supervisorRole->id, $supervisor->role_id);
        $this->assertTrue($supervisor->roles->contains($supervisorRole));
    }

    public function test_trainee1_and_trainee2_exist_with_proper_roles_and_can_login(): void
    {
        $cpsp1 = Tenant::where('domain', 'cpsp1.test')->firstOrFail();
        $traineeType = UserType::where('tenant_id', $cpsp1->id)->where('name', 'Trainee')->firstOrFail();

        $t1 = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'trainee1')->firstOrFail();
        $t2 = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'trainee2')->firstOrFail();

        $this->assertTrue($t1->hasRole('trainee'));
        $this->assertTrue($t2->hasRole('trainee'));
        $this->assertEquals('Trainee 1', $t1->profile?->full_name);
        $this->assertEquals('Trainee 2', $t2->profile?->full_name);

        // Login as trainee1
        $response = $this->post('http://cpsp1.test/login', [
            'username'     => 'trainee1',
            'password'     => 'password',
            'user_type_id' => $traineeType->id,
        ]);

        $response->assertRedirect('http://cpsp1.test/dashboard');
        $this->assertEquals('trainee1', session('username'));
        $this->assertEquals('Trainee', session('user_type'));
    }

    public function test_dynamic_tenant_configuration_and_programs_without_hardcoding(): void
    {
        // 1. Verify dynamic helper on LookupService
        $this->assertNotEmpty(\App\Services\LookupService::formTypes());
        $this->assertNotEmpty(\App\Services\LookupService::levels());
        $this->assertNotEmpty(\App\Services\LookupService::outcomes());
        $this->assertNotEmpty(\App\Services\LookupService::genders());
        $this->assertNotEmpty(\App\Services\LookupService::ageUnits());

        // 2. Create a brand new tenant with arbitrary specialty and custom programs
        $newTenant = Tenant::updateOrCreate(
            ['domain' => 'pediatrics.test'],
            [
                'name'            => 'Pediatrics e-Logbook',
                'specialty_title' => 'PEDIATRICS & CHILD HEALTH',
                'programs'        => [
                    'PEDS' => 'General Pediatrics',
                    'NEO'  => 'Neonatology',
                ],
                'competency_type' => 'fcps_imm',
                'is_active'       => true,
            ]
        );

        $traineeType = UserType::firstOrCreate([
            'tenant_id' => $newTenant->id,
            'name'      => 'Trainee',
        ]);

        $user = User::withoutGlobalScope('tenant')->updateOrCreate(
            ['tenant_id' => $newTenant->id, 'username' => 'ped_trainee'],
            [
                'user_type_id' => $traineeType->id,
                'email'        => 'peds@pediatrics.local',
                'password'     => bcrypt('password'),
            ]
        );

        // 3. Test dynamic specialty title and available programs on Tenant model
        $this->assertEquals('PEDIATRICS & CHILD HEALTH', $newTenant->getSpecialtyTitle());
        $this->assertArrayHasKey('PEDS', $newTenant->getAvailablePrograms());
        $this->assertArrayHasKey('NEO', $newTenant->getAvailablePrograms());

        // 4. Test dynamic program badge
        $metaPeds = Tenant::getProgramMeta('PEDS');
        $this->assertEquals('PEDS', $metaPeds['code']);

        // 5. Test accessing training create on this dynamic tenant
        $session = [
            'user_id'      => $user->id,
            'user_type_id' => $traineeType->id,
            'username'     => 'ped_trainee',
            'user_type'    => 'Trainee',
            'tenant_id'    => $newTenant->id,
        ];

        $response = $this->withSession($session)->get('http://pediatrics.test/training/create');
        $response->assertStatus(200);
        $response->assertSee('PEDIATRICS & CHILD HEALTH');
        $response->assertSee('value="PEDS"', false);
        $response->assertSee('value="NEO"', false);

        // Clean up
        $user->delete();
        $traineeType->delete();
        $newTenant->delete();
    }

    public function test_supervisor_trainee_assignment_and_request_isolation(): void
    {
        $cpsp1 = Tenant::where('domain', 'cpsp1.test')->firstOrFail();
        $sup1 = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'supervisor01')->firstOrFail();
        $sup2 = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'supervisor02')->firstOrFail();
        $trainee1 = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'trainee1')->firstOrFail();
        $trainee2 = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'trainee2')->firstOrFail();

        // Ensure assignments: Trainee 1 belongs to Supervisor 1, Trainee 2 belongs to Supervisor 2
        $trainee1->update(['supervisor_id' => $sup1->id]);
        $trainee2->update(['supervisor_id' => $sup2->id]);

        $this->assertEquals($sup1->id, $trainee1->fresh()->supervisor_id);
        $this->assertEquals($sup2->id, $trainee2->fresh()->supervisor_id);

        // Trainee 1 creates a training entry
        $entry1 = TrainingEntry::withoutGlobalScope('tenant')->create([
            'tenant_id'         => $cpsp1->id,
            'user_id'           => $trainee1->id,
            'supervisor_id'     => $sup1->id,
            'entry_type'        => 'training',
            'form_type'         => '1',
            'hospt_reg_no'      => 'REG-SUP1-T1-999',
            'pt_diagnosis'      => 'Supervisor1 Specific Diagnosis',
            'brief_desc'        => 'Procedure under Supervisor 1',
            'level_id'          => '2',
            'outcome_id'        => '1',
            'under_sup_name'    => 'Dr. Supervisor Demo',
            'pt_gender'         => 'Male',
            'pt_age'            => '30',
            'pt_age_type'       => 'Year[s]',
            'std_post'          => 'Yes',
            'entry_status'      => 'Awaiting Approval',
        ]);

        // Supervisor 1 logs in and visits review page: should SEE entry1
        $responseSup1 = $this->withSession([
            'user_id'      => $sup1->id,
            'tenant_id'    => $cpsp1->id,
            'user_type_id' => $sup1->user_type_id,
            'username'     => $sup1->username,
            'user_type'    => 'Supervisor',
        ])->get('http://cpsp1.test/supervisor/entries?status=Awaiting+Approval');

        $responseSup1->assertStatus(200);
        $responseSup1->assertSee('Supervisor1 Specific Diagnosis');
        $responseSup1->assertSee('REG-SUP1-T1-999');

        // Supervisor 2 logs in and visits review page: should NOT SEE entry1
        $responseSup2 = $this->withSession([
            'user_id'      => $sup2->id,
            'tenant_id'    => $cpsp1->id,
            'user_type_id' => $sup2->user_type_id,
            'username'     => $sup2->username,
            'user_type'    => 'Supervisor',
        ])->get('http://cpsp1.test/supervisor/entries?status=Awaiting+Approval');

        $responseSup2->assertStatus(200);
        $responseSup2->assertDontSee('Supervisor1 Specific Diagnosis');
        $responseSup2->assertDontSee('REG-SUP1-T1-999');

        // Supervisor 2 attempts to view detail of entry1: should be 403 Forbidden!
        $unauthorizedDetail = $this->withSession([
            'user_id'      => $sup2->id,
            'tenant_id'    => $cpsp1->id,
            'user_type_id' => $sup2->user_type_id,
            'username'     => $sup2->username,
            'user_type'    => 'Supervisor',
        ])->get('http://cpsp1.test/supervisor/entries/training/' . $entry1->id);

        $unauthorizedDetail->assertStatus(403);

        // Supervisor 2 attempts to approve entry1: should be 403 Forbidden!
        $unauthorizedApprove = $this->withSession([
            'user_id'      => $sup2->id,
            'tenant_id'    => $cpsp1->id,
            'user_type_id' => $sup2->user_type_id,
            'username'     => $sup2->username,
            'user_type'    => 'Supervisor',
        ])->post('http://cpsp1.test/supervisor/entries/training/' . $entry1->id . '/status', [
            'status' => 'Approved',
        ]);

        $unauthorizedApprove->assertStatus(403);
        $this->assertEquals('Awaiting Approval', $entry1->fresh()->entry_status);

        // Supervisor 1 approves entry1: should succeed!
        $authorizedApprove = $this->withSession([
            'user_id'      => $sup1->id,
            'tenant_id'    => $cpsp1->id,
            'user_type_id' => $sup1->user_type_id,
            'username'     => $sup1->username,
            'user_type'    => 'Supervisor',
        ])->post('http://cpsp1.test/supervisor/entries/training/' . $entry1->id . '/status', [
            'status' => 'Approved',
            'supervisor_remarks' => 'Approved by assigned supervisor',
        ]);

        $authorizedApprove->assertRedirect();
        $this->assertEquals('Approved', $entry1->fresh()->entry_status);
        $this->assertEquals($sup1->id, $entry1->fresh()->approved_by);

        // Clean up
        $entry1->delete();
    }

    public function test_asghar_hafiz_and_assigned_trainees_salochina_maria_amarta_iqra(): void
    {
        $cpsp1 = Tenant::where('domain', 'cpsp1.test')->firstOrFail();

        $asghar = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'asghar')->firstOrFail();
        $hafiz = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'hafiz')->firstOrFail();
        $salochina = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'salochina')->firstOrFail();
        $maria = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'maria')->firstOrFail();
        $amarta = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'amarta')->firstOrFail();
        $iqra = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'iqra')->firstOrFail();

        // Check roles & types
        $this->assertTrue($asghar->isSupervisor());
        $this->assertTrue($hafiz->isSupervisor());
        $this->assertTrue($salochina->isTrainee());
        $this->assertTrue($maria->isTrainee());
        $this->assertTrue($amarta->isTrainee());
        $this->assertTrue($iqra->isTrainee());

        // Check assigned supervisors
        $this->assertEquals($asghar->id, $salochina->supervisor_id);
        $this->assertEquals($asghar->id, $maria->supervisor_id);
        $this->assertEquals($hafiz->id, $amarta->supervisor_id);
        $this->assertEquals($hafiz->id, $iqra->supervisor_id);

        // Check Asghar's assigned trainees
        $asgharTraineeIds = $asghar->getAssignedTraineeIds();
        $this->assertContains($salochina->id, $asgharTraineeIds);
        $this->assertContains($maria->id, $asgharTraineeIds);
        $this->assertNotContains($amarta->id, $asgharTraineeIds);
        $this->assertNotContains($iqra->id, $asgharTraineeIds);

        // Check Hafiz's assigned trainees
        $hafizTraineeIds = $hafiz->getAssignedTraineeIds();
        $this->assertContains($amarta->id, $hafizTraineeIds);
        $this->assertContains($iqra->id, $hafizTraineeIds);
        $this->assertNotContains($salochina->id, $hafizTraineeIds);
        $this->assertNotContains($maria->id, $hafizTraineeIds);

        // Salochina submits a training entry
        $salochinaEntry = TrainingEntry::withoutGlobalScope('tenant')->create([
            'tenant_id'         => $cpsp1->id,
            'user_id'           => $salochina->id,
            'supervisor_id'     => $asghar->id,
            'entry_type'        => 'training',
            'form_type'         => '1',
            'hospt_reg_no'      => 'SALO-001',
            'pt_diagnosis'      => 'Salochina Patient Case',
            'brief_desc'        => 'Case managed under Dr. Asghar',
            'level_id'          => '2',
            'outcome_id'        => '1',
            'under_sup_name'    => 'Dr. Asghar',
            'pt_gender'         => 'Female',
            'pt_age'            => '28',
            'pt_age_type'       => 'Year[s]',
            'std_post'          => 'Yes',
            'entry_status'      => 'Awaiting Approval',
        ]);

        // Amarta submits a training entry
        $amartaEntry = TrainingEntry::withoutGlobalScope('tenant')->create([
            'tenant_id'         => $cpsp1->id,
            'user_id'           => $amarta->id,
            'supervisor_id'     => $hafiz->id,
            'entry_type'        => 'training',
            'form_type'         => '1',
            'hospt_reg_no'      => 'AMAR-001',
            'pt_diagnosis'      => 'Amarta Patient Case',
            'brief_desc'        => 'Case managed under Dr. Hafiz',
            'level_id'          => '2',
            'outcome_id'        => '1',
            'under_sup_name'    => 'Dr. Hafiz',
            'pt_gender'         => 'Male',
            'pt_age'            => '45',
            'pt_age_type'       => 'Year[s]',
            'std_post'          => 'Yes',
            'entry_status'      => 'Awaiting Approval',
        ]);

        // Dr. Asghar logs in
        $responseAsghar = $this->withSession([
            'user_id'      => $asghar->id,
            'tenant_id'    => $cpsp1->id,
            'user_type_id' => $asghar->user_type_id,
            'username'     => $asghar->username,
            'user_type'    => 'Supervisor',
        ])->get('http://cpsp1.test/supervisor/entries?status=Awaiting+Approval');

        $responseAsghar->assertStatus(200);
        $responseAsghar->assertSee('Salochina Patient Case');
        $responseAsghar->assertDontSee('Amarta Patient Case');

        // Dr. Hafiz logs in
        $responseHafiz = $this->withSession([
            'user_id'      => $hafiz->id,
            'tenant_id'    => $cpsp1->id,
            'user_type_id' => $hafiz->user_type_id,
            'username'     => $hafiz->username,
            'user_type'    => 'Supervisor',
        ])->get('http://cpsp1.test/supervisor/entries?status=Awaiting+Approval');

        $responseHafiz->assertStatus(200);
        $responseHafiz->assertSee('Amarta Patient Case');
        $responseHafiz->assertDontSee('Salochina Patient Case');

        // Clean up
        $salochinaEntry->delete();
        $amartaEntry->delete();
    }

    public function test_manual_supervisor_entry_and_validation_error_with_input_retention(): void
    {
        $cpsp1 = Tenant::where('domain', 'cpsp1.test')->firstOrFail();
        $asghar = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'asghar')->firstOrFail();
        $salochina = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'salochina')->firstOrFail();

        // 1. Visit form: should have manual input 'under_sup_name' and NO dropdown for supervisor_id
        $createPage = $this->withSession([
            'user_id'      => $salochina->id,
            'tenant_id'    => $cpsp1->id,
            'user_type_id' => $salochina->user_type_id,
            'username'     => $salochina->username,
            'user_type'    => 'Trainee',
        ])->get('http://cpsp1.test/training/create');

        $createPage->assertStatus(200);
        $createPage->assertSee('name="under_sup_name"', false);
        $createPage->assertDontSee('<select name="supervisor_id"', false);

        // 2. Submit incomplete form (fill some fields, leave required ones blank)
        $incompletePost = $this->withSession([
            'user_id'      => $salochina->id,
            'tenant_id'    => $cpsp1->id,
            'user_type_id' => $salochina->user_type_id,
            'username'     => $salochina->username,
            'user_type'    => 'Trainee',
        ])->from('http://cpsp1.test/training/create')->post('http://cpsp1.test/training', [
            'hospt_reg_no'   => 'RETAIN-TEST-5555',
            'pt_diagnosis'   => 'Retained Test Diagnosis',
            'under_sup_name' => 'Dr. Asghar',
            // Missing: form_type, date_of_admission, pt_gender, pt_age, pt_age_type, level_id, outcome_id, brief_desc, std_post
        ]);

        $incompletePost->assertRedirect('http://cpsp1.test/training/create');
        $incompletePost->assertSessionHas('flash_err', 'Please fill all the required fields.');
        $incompletePost->assertSessionHasErrors(['form_type', 'date_of_admission', 'pt_gender', 'pt_age', 'level_id', 'outcome_id', 'brief_desc', 'std_post']);

        // 3. Test input retention and error banner when redirected back
        $redirectResponse = $this->withSession([
            'user_id'      => $salochina->id,
            'tenant_id'    => $cpsp1->id,
            'user_type_id' => $salochina->user_type_id,
            'username'     => $salochina->username,
            'user_type'    => 'Trainee',
        ])->followingRedirects()->from('http://cpsp1.test/training/create')->post('http://cpsp1.test/training', [
            'hospt_reg_no'   => 'RETAIN-TEST-5555',
            'pt_diagnosis'   => 'Retained Test Diagnosis',
            'under_sup_name' => 'Dr. Asghar',
        ]);

        $redirectResponse->assertStatus(200);
        $redirectResponse->assertSee('Please fill all the required fields.');
        $redirectResponse->assertSee('value="RETAIN-TEST-5555"', false);
        $redirectResponse->assertSee('value="Retained Test Diagnosis"', false);

        // 4. Submit fully completed form with manual supervisor text "Dr. Asghar"
        $completePost = $this->withSession([
            'user_id'      => $salochina->id,
            'tenant_id'    => $cpsp1->id,
            'user_type_id' => $salochina->user_type_id,
            'username'     => $salochina->username,
            'user_type'    => 'Trainee',
        ])->post('http://cpsp1.test/training', [
            'form_type'         => 'Indoor',
            'hospt_reg_no'      => 'REG-MANUAL-SUP-1',
            'date_of_admission' => '05-01-2025',
            'pt_gender'         => 'Female',
            'pt_age'            => '29',
            'pt_age_type'       => 'Year[s]',
            'pt_diagnosis'      => 'Manual Supervisor Routing Diagnosis',
            'under_sup_name'    => 'Dr. Asghar',
            'level_id'          => 'Resident / Fellow',
            'outcome_id'        => 'Recovered',
            'brief_desc'        => 'Full description',
            'entry_for_prog_id' => 'MD',
            'std_post'          => 'Yes',
        ]);

        $completePost->assertRedirect('http://cpsp1.test/training');

        $createdEntry = TrainingEntry::where('hospt_reg_no', 'REG-MANUAL-SUP-1')->first();
        $this->assertNotNull($createdEntry);
        $this->assertEquals($asghar->id, $createdEntry->supervisor_id);
        $this->assertEquals('Dr. Asghar', $createdEntry->under_sup_name);

        $createdEntry->delete();
    }

    public function test_rotational_manual_supervisor_entry_and_validation_retention(): void
    {
        $cpsp1 = Tenant::where('domain', 'cpsp1.test')->firstOrFail();
        $hafiz = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'hafiz')->firstOrFail();
        $amarta = User::withoutGlobalScope('tenant')->where('tenant_id', $cpsp1->id)->where('username', 'amarta')->firstOrFail();

        // 1. Visit rotational form: manual input 'under_sup_name', NO supervisor_id dropdown
        $createPage = $this->withSession([
            'user_id'      => $amarta->id,
            'tenant_id'    => $cpsp1->id,
            'user_type_id' => $amarta->user_type_id,
            'username'     => $amarta->username,
            'user_type'    => 'Trainee',
        ])->get('http://cpsp1.test/rotational/create');

        $createPage->assertStatus(200);
        $createPage->assertSee('name="under_sup_name"', false);
        $createPage->assertDontSee('<select name="supervisor_id"', false);

        // 2. Submit incomplete rotational form: verify error and input retention
        $redirectResponse = $this->withSession([
            'user_id'      => $amarta->id,
            'tenant_id'    => $cpsp1->id,
            'user_type_id' => $amarta->user_type_id,
            'username'     => $amarta->username,
            'user_type'    => 'Trainee',
        ])->followingRedirects()->from('http://cpsp1.test/rotational/create')->post('http://cpsp1.test/rotational', [
            'hospt_reg_no'   => 'ROT-RETAIN-777',
            'pt_diagnosis'   => 'Rotational Retained Diagnosis',
            'under_sup_name' => 'Dr. Hafiz',
        ]);

        $redirectResponse->assertStatus(200);
        $redirectResponse->assertSee('Please fill all the required fields.');
        $redirectResponse->assertSee('value="ROT-RETAIN-777"', false);
        $redirectResponse->assertSee('value="Rotational Retained Diagnosis"', false);

        // 3. Complete and submit rotational entry with manual supervisor
        $completePost = $this->withSession([
            'user_id'      => $amarta->id,
            'tenant_id'    => $cpsp1->id,
            'user_type_id' => $amarta->user_type_id,
            'username'     => $amarta->username,
            'user_type'    => 'Trainee',
        ])->post('http://cpsp1.test/rotational', [
            'form_type'         => 'Outdoor',
            'entry_for_prog_id' => 'MD',
            'hospt_reg_no'      => 'ROT-MANUAL-1',
            'date_of_admission' => '10-02-2025',
            'pt_gender'         => 'Male',
            'pt_age'            => '45',
            'pt_age_type'       => 'Year[s]',
            'pt_diagnosis'      => 'Rotational Cardio Diagnosis',
            'under_sup_name'    => 'Dr. Hafiz',
            'level_id'          => 'Resident / Fellow',
            'outcome_id'        => 'Recovered',
            'brief_desc'        => 'Cardio rotational details',
            'std_post'          => 'Yes',
        ]);

        $completePost->assertRedirect('http://cpsp1.test/rotational');

        $createdRot = \App\Models\RotationalEntry::where('hospt_reg_no', 'ROT-MANUAL-1')->first();
        $this->assertNotNull($createdRot);
        $this->assertEquals($hafiz->id, $createdRot->supervisor_id);
        $this->assertEquals('Dr. Hafiz', $createdRot->under_sup_name);

        $createdRot->delete();
    }
}
